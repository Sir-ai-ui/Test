# Elektroplanung

Client-Server-Variante der Elektroplanungs-App.

```
elektroplanung/
├── docker-compose.yml      # Postgres + Backend
├── backend/                # FastAPI
│   ├── Dockerfile
│   ├── requirements.txt
│   ├── main.py             # App, Health, Frontend-Auslieferung
│   ├── database.py         # Engine/Session/Init
│   ├── models.py           # Tabellen (users, projekte, plan_dateien)
│   ├── schemas.py
│   └── routers/            # projekte / upload / auth (ab Stufe 2)
└── frontend/
    └── index.html          # die App
```

## Starten

```bash
cd elektroplanung
docker compose up --build
```

## Testen (Stufe 1)

| URL | erwartet |
|-----|----------|
| `http://<server>:8000/`            | die App (Frontend) |
| `http://<server>:8000/docs`        | Swagger-API-Doku |
| `http://<server>:8000/api/health`  | `{"status":"ok","db":"ok"}` |

`api/health` liefert nur dann `db:"ok"`, wenn das Backend die Postgres-DB
erreicht — damit ist die ganze Kette (Backend ↔ DB) getestet.

DB-Tabellen prüfen (optional):

```bash
docker compose exec db psql -U elektro -d elektroplanung -c "\dt"
# erwartet: users, projekte, plan_dateien
```

## Testen — Projekte-API (Stufe 2)

Am einfachsten über `http://<server>:8000/docs` (Buttons „Try it out"), oder per curl:

```bash
# anlegen
curl -X POST http://localhost:8000/api/projekte \
  -H 'Content-Type: application/json' \
  -d '{"name":"Testhaus","daten":{}}'

# auflisten / lesen / aktualisieren / löschen
curl http://localhost:8000/api/projekte
curl http://localhost:8000/api/projekte/1
curl -X PUT http://localhost:8000/api/projekte/1 \
  -H 'Content-Type: application/json' -d '{"name":"Testhaus EG"}'
curl -X DELETE http://localhost:8000/api/projekte/1
```

## Testen — Upload-API (Stufe 3)

```bash
# Bild zu Projekt 1 hochladen (Feld "datei", optional "etage")
curl -X POST http://localhost:8000/api/projekte/1/dateien \
  -F 'datei=@grundriss.png' -F 'etage=Erdgeschoss'

# Dateien eines Projekts auflisten
curl http://localhost:8000/api/projekte/1/dateien

# Inhalt abrufen (im Browser: /api/dateien/1/inhalt -> Bild)
# löschen
curl -X DELETE http://localhost:8000/api/dateien/1
```

Antwort beim Upload enthält `url` (z. B. `/api/dateien/1/inhalt`) — diese URL
nutzt das Frontend ab Stufe 4 als Bildquelle statt base64. Dateien liegen im
Volume `uploads` (Pfad `uploads/<projekt_id>/<uuid>.<ext>`), max. 30 MB
(über `MAX_UPLOAD_MB` einstellbar).

## Stufenplan

1. ~~Grundgerüst~~ ✅ Compose, DB, Tabellen inkl. `users`, Health, Frontend.
2. ~~Projekte-API~~ ✅ CRUD, Planungs-JSON im Feld `daten`.
3. ~~Upload-API~~ ✅ Grundriss-Bilder als Dateien (Volume).
4. ~~Frontend-Anbindung~~ ✅ Projekt-Verwaltung, Autosave in die DB, Grundriss-Upload, Offline-Fallback.
5. Auth (Login/JWT).

## Frontend ↔ Backend (Stufe 4)

Das Frontend erkennt das Backend automatisch über `/api/health` (same-origin,
da das Backend die Seite selbst ausliefert):

- **Online** (Backend erreichbar): oben in der Topbar erscheint die
  **Projektauswahl** (grüner Punkt, Dropdown, „+" neu, „✎" umbenennen, „×"
  löschen). Jede Änderung wird automatisch in die DB gespeichert
  (Status rechts: „Speichert… / Gespeichert"). Grundrisse werden als
  **Datei hochgeladen** (`/api/dateien/…`) statt als base64.
- **Offline** (z. B. Datei direkt geöffnet): Anzeige „Offline · lokal",
  alles läuft wie bisher über `localStorage`. „↻" versucht erneut zu verbinden.

Beim ersten Online-Start ohne vorhandene Projekte wird automatisch ein Projekt
„Neues Projekt" aus dem aktuellen (lokalen) Stand angelegt. Bereits lokal
importierte Grundrisse bleiben als base64 erhalten — neu importieren wandelt
sie in echte Datei-Uploads um (schlanker in der DB).

### Schnelltest

1. `docker compose up --build`, dann `http://<server>:8000/` öffnen.
2. Grüner Punkt + Projektauswahl sichtbar → Backend verbunden.
3. Element platzieren → Status wechselt kurz auf „Speichert…" → „Gespeichert".
4. Seite neu laden → Planung kommt aus der DB zurück.
5. Grundriss importieren → liegt danach unter `/api/projekte/<id>/dateien`.

> Hinweis: In Stufe 1 läuft das Frontend noch unverändert auf `localStorage`.
> Die Anbindung an die DB kommt in Stufe 4.
