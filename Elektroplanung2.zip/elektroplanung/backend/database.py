"""Datenbank-Setup: Engine, Session, Base, Init mit Retry."""
import os
import time

from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker, DeclarativeBase

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql+psycopg://elektro:elektro_pw@db:5432/elektroplanung",
)

engine = create_engine(DATABASE_URL, pool_pre_ping=True, future=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)


class Base(DeclarativeBase):
    """Basisklasse für alle ORM-Modelle."""
    pass


def get_db():
    """FastAPI-Dependency: liefert eine DB-Session pro Request."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def init_db():
    """Wartet auf die DB und legt alle Tabellen an (idempotent)."""
    # Import sorgt dafür, dass alle Modelle bei create_all() registriert sind.
    import models  # noqa: F401

    last_err = None
    for _ in range(15):
        try:
            with engine.connect() as conn:
                conn.execute(text("SELECT 1"))
            Base.metadata.create_all(bind=engine)
            return
        except Exception as err:  # DB evtl. noch nicht bereit
            last_err = err
            time.sleep(2)
    raise RuntimeError(f"Datenbank nicht erreichbar: {last_err}")
