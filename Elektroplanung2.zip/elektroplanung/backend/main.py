"""FastAPI-Einstiegspunkt.

Stufe 1: Health-Check (inkl. DB-Test), Frontend-Auslieferung, CORS.
Die fachlichen Router (projekte, upload, auth) werden in den nächsten Stufen
ergänzt — die Imports stehen unten schon auskommentiert bereit.
"""
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from sqlalchemy import text
from sqlalchemy.orm import Session

from database import init_db, get_db
from schemas import HealthOut


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()          # DB abwarten + Tabellen anlegen
    yield


app = FastAPI(title="Elektroplanung API", version="0.3.0", lifespan=lifespan)

# CORS (Frontend wird zwar same-origin ausgeliefert, aber für externe Clients offen)
origins = [o.strip() for o in os.getenv("CORS_ORIGINS", "*").split(",") if o.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins or ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/health", response_model=HealthOut, tags=["system"])
def health(db: Session = Depends(get_db)):
    """Prüft Backend + Datenbankverbindung."""
    db.execute(text("SELECT 1"))
    return HealthOut(status="ok", db="ok")


# --- Fachliche Router ------------------------------------------------------
from routers import projekte, upload  # noqa: E402
app.include_router(projekte.router, prefix="/api")
app.include_router(upload.router, prefix="/api")

# Folgt in den nächsten Stufen:
# from routers import auth
# app.include_router(auth.router,   prefix="/api")
# ---------------------------------------------------------------------------

# Frontend statisch ausliefern. WICHTIG: zuletzt mounten, damit /api und /docs
# Vorrang behalten (StaticFiles am Mount "/" fängt sonst alles ab).
if os.path.isdir("frontend"):
    app.mount("/", StaticFiles(directory="frontend", html=True), name="frontend")
