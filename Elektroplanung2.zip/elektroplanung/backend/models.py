"""ORM-Tabellen. users ist von Anfang an dabei (Auth folgt in Stufe 5)."""
import datetime

from sqlalchemy import (
    String, Boolean, BigInteger, ForeignKey, DateTime, func,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from database import Base


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    hashed_password: Mapped[str] = mapped_column(String(255), default="")
    name: Mapped[str] = mapped_column(String(120), default="")
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    is_admin: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime.datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )

    projekte: Mapped[list["Projekt"]] = relationship(
        back_populates="owner"
    )


class Projekt(Base):
    __tablename__ = "projekte"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(200))
    owner_id: Mapped[int | None] = mapped_column(
        ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    # Kompletter Planungszustand (Etagen, Elemente, Kabel, Stromkreise) als JSON.
    daten: Mapped[dict] = mapped_column(JSONB, default=dict)
    created_at: Mapped[datetime.datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    updated_at: Mapped[datetime.datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    owner: Mapped["User | None"] = relationship(back_populates="projekte")
    dateien: Mapped[list["PlanDatei"]] = relationship(
        back_populates="projekt", cascade="all, delete-orphan"
    )


class PlanDatei(Base):
    """Hochgeladene Grundriss-Bilder (Inhalt liegt auf der Platte, ab Stufe 3)."""
    __tablename__ = "plan_dateien"

    id: Mapped[int] = mapped_column(primary_key=True)
    projekt_id: Mapped[int] = mapped_column(
        ForeignKey("projekte.id", ondelete="CASCADE")
    )
    dateiname: Mapped[str] = mapped_column(String(255))        # gespeicherter Name
    original_name: Mapped[str] = mapped_column(String(255), default="")
    content_type: Mapped[str] = mapped_column(String(120), default="")
    groesse: Mapped[int] = mapped_column(BigInteger, default=0)
    etage: Mapped[str] = mapped_column(String(120), default="")
    created_at: Mapped[datetime.datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )

    projekt: Mapped["Projekt"] = relationship(back_populates="dateien")
