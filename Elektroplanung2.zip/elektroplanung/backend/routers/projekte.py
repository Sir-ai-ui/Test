"""Projekte-API: anlegen, auflisten, lesen, aktualisieren, löschen.

Ein Projekt enthält den kompletten Planungszustand (Etagen, Elemente, Kabel,
Stromkreise) als JSON im Feld `daten`. Die Bindung an Benutzer (owner_id)
bleibt bis Stufe 5 (Auth) offen.
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

import models
from database import get_db
from schemas import ProjektCreate, ProjektUpdate, ProjektOut, ProjektDetail

router = APIRouter(prefix="/projekte", tags=["projekte"])


@router.get("", response_model=list[ProjektOut])
def liste(db: Session = Depends(get_db)):
    """Alle Projekte, zuletzt geändertes zuerst."""
    stmt = select(models.Projekt).order_by(models.Projekt.updated_at.desc())
    return db.scalars(stmt).all()


@router.post("", response_model=ProjektDetail, status_code=201)
def anlegen(payload: ProjektCreate, db: Session = Depends(get_db)):
    projekt = models.Projekt(name=payload.name, daten=payload.daten or {})
    db.add(projekt)
    db.commit()
    db.refresh(projekt)
    return projekt


@router.get("/{projekt_id}", response_model=ProjektDetail)
def holen(projekt_id: int, db: Session = Depends(get_db)):
    projekt = db.get(models.Projekt, projekt_id)
    if projekt is None:
        raise HTTPException(status_code=404, detail="Projekt nicht gefunden")
    return projekt


@router.put("/{projekt_id}", response_model=ProjektDetail)
def aktualisieren(projekt_id: int, payload: ProjektUpdate, db: Session = Depends(get_db)):
    projekt = db.get(models.Projekt, projekt_id)
    if projekt is None:
        raise HTTPException(status_code=404, detail="Projekt nicht gefunden")
    if payload.name is not None:
        projekt.name = payload.name
    if payload.daten is not None:
        projekt.daten = payload.daten
    db.commit()
    db.refresh(projekt)
    return projekt


@router.delete("/{projekt_id}", status_code=204)
def loeschen(projekt_id: int, db: Session = Depends(get_db)):
    projekt = db.get(models.Projekt, projekt_id)
    if projekt is None:
        raise HTTPException(status_code=404, detail="Projekt nicht gefunden")
    db.delete(projekt)
    db.commit()
