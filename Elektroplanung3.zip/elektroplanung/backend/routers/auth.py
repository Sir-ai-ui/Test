"""Auth-API: Registrierung, Login, eigener Benutzer.

- Der erste registrierte Benutzer wird automatisch Admin.
- Offene Registrierung lässt sich per Env ALLOW_REGISTRATION=false abschalten
  (dann kann nur ein Admin neue Konten anlegen — Endpunkt folgt bei Bedarf).
"""
import os

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select, func
from sqlalchemy.orm import Session

import models
from database import get_db
from schemas import RegisterIn, LoginIn, TokenOut, UserOut
from security import hash_password, verify_password, create_access_token, get_current_user

router = APIRouter(prefix="/auth", tags=["auth"])

ALLOW_REGISTRATION = os.getenv("ALLOW_REGISTRATION", "true").lower() == "true"


@router.post("/register", response_model=TokenOut, status_code=201)
def register(payload: RegisterIn, db: Session = Depends(get_db)):
    anzahl = db.scalar(select(func.count()).select_from(models.User)) or 0
    if not ALLOW_REGISTRATION and anzahl > 0:
        raise HTTPException(status_code=403, detail="Registrierung ist deaktiviert")

    email = payload.email.lower().strip()
    vorhanden = db.scalar(select(models.User).where(models.User.email == email))
    if vorhanden is not None:
        raise HTTPException(status_code=409, detail="E-Mail ist bereits registriert")

    user = models.User(
        email=email,
        hashed_password=hash_password(payload.password),
        name=payload.name.strip(),
        is_admin=(anzahl == 0),   # erster Benutzer = Admin
        is_active=True,
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return TokenOut(access_token=create_access_token(user.id), user=UserOut.model_validate(user))


@router.post("/login", response_model=TokenOut)
def login(payload: LoginIn, db: Session = Depends(get_db)):
    email = payload.email.lower().strip()
    user = db.scalar(select(models.User).where(models.User.email == email))
    if user is None or not verify_password(payload.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="E-Mail oder Passwort falsch")
    if not user.is_active:
        raise HTTPException(status_code=403, detail="Konto ist deaktiviert")
    return TokenOut(access_token=create_access_token(user.id), user=UserOut.model_validate(user))


@router.get("/me", response_model=UserOut)
def me(user: models.User = Depends(get_current_user)):
    return user
