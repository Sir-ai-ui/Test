"""Projekte-API: anlegen, auflisten, lesen, aktualisieren, löschen.

Ab Stufe 5 ist jeder Endpunkt geschützt — Projekte gehören einem Benutzer.
Normale Benutzer sehen/bearbeiten nur eigene Projekte, Admins alle.
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

import models
from database import get_db
from security import get_current_user
from schemas import ProjektCreate, ProjektUpdate, ProjektOut, ProjektDetail

router = APIRouter(prefix="/projekte", tags=["projekte"])


def _projekt_oder_404(projekt_id: int, db: Session, user: models.User) -> models.Projekt:
    projekt = db.get(models.Projekt, projekt_id)
    if projekt is None:
        raise HTTPException(status_code=404, detail="Projekt nicht gefunden")
    if not user.is_admin and projekt.owner_id != user.id:
        raise HTTPException(status_code=403, detail="Kein Zugriff auf dieses Projekt")
    return projekt


@router.get("", response_model=list[ProjektOut])
def liste(db: Session = Depends(get_db), user: models.User = Depends(get_current_user)):
    """Eigene Projekte (Admin: alle), zuletzt geändertes zuerst."""
    stmt = select(models.Projekt).order_by(models.Projekt.updated_at.desc())
    if not user.is_admin:
        stmt = stmt.where(models.Projekt.owner_id == user.id)
    return db.scalars(stmt).all()


@router.post("", response_model=ProjektDetail, status_code=201)
def anlegen(payload: ProjektCreate, db: Session = Depends(get_db), user: models.User = Depends(get_current_user)):
    projekt = models.Projekt(name=payload.name, daten=payload.daten or {}, owner_id=user.id)
    db.add(projekt)
    db.commit()
    db.refresh(projekt)
    return projekt


@router.get("/{projekt_id}", response_model=ProjektDetail)
def holen(projekt_id: int, db: Session = Depends(get_db), user: models.User = Depends(get_current_user)):
    return _projekt_oder_404(projekt_id, db, user)


@router.put("/{projekt_id}", response_model=ProjektDetail)
def aktualisieren(projekt_id: int, payload: ProjektUpdate, db: Session = Depends(get_db), user: models.User = Depends(get_current_user)):
    projekt = _projekt_oder_404(projekt_id, db, user)
    if payload.name is not None:
        projekt.name = payload.name
    if payload.daten is not None:
        projekt.daten = payload.daten
    db.commit()
    db.refresh(projekt)
    return projekt


@router.delete("/{projekt_id}", status_code=204)
def loeschen(projekt_id: int, db: Session = Depends(get_db), user: models.User = Depends(get_current_user)):
    projekt = _projekt_oder_404(projekt_id, db, user)
    db.delete(projekt)
    db.commit()
