"""Upload-API: Grundriss-Bilder als Dateien speichern und ausliefern.

Dateien liegen auf der Platte unter UPLOAD_DIR/<projekt_id>/<uuid>.<ext>
(im Docker-Setup ein Volume), Metadaten in der Tabelle plan_dateien.
"""
import os
import uuid

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from fastapi.responses import FileResponse
from sqlalchemy import select
from sqlalchemy.orm import Session

import models
from database import get_db
from security import get_current_user, user_from_token
from schemas import PlanDateiOut

router = APIRouter(tags=["upload"])

UPLOAD_DIR = os.getenv("UPLOAD_DIR", "uploads")
MAX_BYTES = int(os.getenv("MAX_UPLOAD_MB", "30")) * 1024 * 1024
EXT_BY_TYPE = {
    "image/png": ".png", "image/jpeg": ".jpg", "image/jpg": ".jpg",
    "image/webp": ".webp", "image/gif": ".gif", "image/svg+xml": ".svg",
    "image/bmp": ".bmp", "image/tiff": ".tiff",
}


def _mit_url(datei: models.PlanDatei) -> PlanDateiOut:
    out = PlanDateiOut.model_validate(datei)
    out.url = f"/api/dateien/{datei.id}/inhalt"
    return out


def _projekt_oder_404(projekt_id: int, db: Session, user: models.User) -> models.Projekt:
    projekt = db.get(models.Projekt, projekt_id)
    if projekt is None:
        raise HTTPException(status_code=404, detail="Projekt nicht gefunden")
    if not user.is_admin and projekt.owner_id != user.id:
        raise HTTPException(status_code=403, detail="Kein Zugriff auf dieses Projekt")
    return projekt


def _datei_oder_404(datei_id: int, db: Session, user: models.User) -> models.PlanDatei:
    rec = db.get(models.PlanDatei, datei_id)
    if rec is None:
        raise HTTPException(status_code=404, detail="Datei nicht gefunden")
    projekt = db.get(models.Projekt, rec.projekt_id)
    if projekt is not None and not user.is_admin and projekt.owner_id != user.id:
        raise HTTPException(status_code=403, detail="Kein Zugriff auf diese Datei")
    return rec


@router.post("/projekte/{projekt_id}/dateien", response_model=PlanDateiOut, status_code=201)
async def hochladen(
    projekt_id: int,
    datei: UploadFile = File(...),
    etage: str = Form(""),
    db: Session = Depends(get_db),
    user: models.User = Depends(get_current_user),
):
    _projekt_oder_404(projekt_id, db, user)
    ct = (datei.content_type or "").lower()
    if not ct.startswith("image/"):
        raise HTTPException(status_code=415, detail="Nur Bilddateien erlaubt")

    inhalt = await datei.read()
    if len(inhalt) > MAX_BYTES:
        raise HTTPException(status_code=413, detail=f"Datei zu groß (max. {MAX_BYTES // (1024*1024)} MB)")

    ext = EXT_BY_TYPE.get(ct) or os.path.splitext(datei.filename or "")[1] or ".bin"
    ordner = os.path.join(UPLOAD_DIR, str(projekt_id))
    os.makedirs(ordner, exist_ok=True)
    name = uuid.uuid4().hex + ext
    pfad = os.path.join(ordner, name)
    with open(pfad, "wb") as f:
        f.write(inhalt)

    rec = models.PlanDatei(
        projekt_id=projekt_id,
        dateiname=name,
        original_name=datei.filename or name,
        content_type=ct,
        groesse=len(inhalt),
        etage=etage or "",
    )
    db.add(rec)
    db.commit()
    db.refresh(rec)
    return _mit_url(rec)


@router.get("/projekte/{projekt_id}/dateien", response_model=list[PlanDateiOut])
def liste(projekt_id: int, db: Session = Depends(get_db), user: models.User = Depends(get_current_user)):
    _projekt_oder_404(projekt_id, db, user)
    stmt = (
        select(models.PlanDatei)
        .where(models.PlanDatei.projekt_id == projekt_id)
        .order_by(models.PlanDatei.created_at)
    )
    return [_mit_url(d) for d in db.scalars(stmt).all()]


@router.get("/dateien/{datei_id}/inhalt")
def inhalt(datei_id: int, token: str | None = None, db: Session = Depends(get_db)):
    # Bilder werden per <img src> geladen -> kein Authorization-Header möglich.
    # Daher Token als Query-Parameter (?token=...). Zugriff nur auf eigene Projekte.
    user = user_from_token(token or "", db)
    if user is None:
        raise HTTPException(status_code=401, detail="Nicht angemeldet")
    rec = _datei_oder_404(datei_id, db, user)
    pfad = os.path.join(UPLOAD_DIR, str(rec.projekt_id), rec.dateiname)
    if not os.path.isfile(pfad):
        raise HTTPException(status_code=404, detail="Datei-Inhalt fehlt auf der Platte")
    return FileResponse(pfad, media_type=rec.content_type or "application/octet-stream")


@router.delete("/dateien/{datei_id}", status_code=204)
def loeschen(datei_id: int, db: Session = Depends(get_db), user: models.User = Depends(get_current_user)):
    rec = _datei_oder_404(datei_id, db, user)
    pfad = os.path.join(UPLOAD_DIR, str(rec.projekt_id), rec.dateiname)
    try:
        if os.path.isfile(pfad):
            os.remove(pfad)
    except OSError:
        pass
    db.delete(rec)
    db.commit()
