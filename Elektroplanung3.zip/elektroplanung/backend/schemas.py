"""Pydantic-Schemas (Request/Response)."""
import datetime

from pydantic import BaseModel, ConfigDict, Field, EmailStr


class HealthOut(BaseModel):
    status: str
    db: str


# --- Auth / Benutzer -------------------------------------------------------
class RegisterIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=6, max_length=200)
    name: str = Field(default="", max_length=120)


class LoginIn(BaseModel):
    email: EmailStr
    password: str


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    email: EmailStr
    name: str
    is_admin: bool


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


# --- Projekte --------------------------------------------------------------
class ProjektCreate(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    daten: dict = Field(default_factory=dict)   # Planungszustand (Etagen, ...)


class ProjektUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=200)
    daten: dict | None = None


class ProjektOut(BaseModel):
    """Listendarstellung — ohne den (großen) Planungszustand."""
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    owner_id: int | None = None
    created_at: datetime.datetime
    updated_at: datetime.datetime


class ProjektDetail(ProjektOut):
    """Vollständiges Projekt inkl. Planungsdaten."""
    daten: dict


# --- Plan-Dateien (Uploads) ------------------------------------------------
class PlanDateiOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    projekt_id: int
    original_name: str
    content_type: str
    groesse: int
    etage: str
    created_at: datetime.datetime
    url: str = ""   # wird im Router gesetzt: /api/dateien/{id}/inhalt
