"""Sicherheit: Passwort-Hashing (bcrypt) + JWT + aktueller Benutzer.

JWT_SECRET MUSS in der Produktion gesetzt werden (docker-compose), sonst sind
nach einem Neustart alle Tokens ungültig bzw. unsicher.
"""
import os
import datetime

import bcrypt
import jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session

import models
from database import get_db

JWT_SECRET = os.getenv("JWT_SECRET", "dev-unsicher-bitte-setzen")
JWT_ALG = "HS256"
TOKEN_TTL = datetime.timedelta(days=int(os.getenv("TOKEN_TTL_DAYS", "7")))

_bearer = HTTPBearer(auto_error=False)


def hash_password(passwort: str) -> str:
    return bcrypt.hashpw(passwort.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(passwort: str, hashed: str) -> bool:
    if not hashed:
        return False
    try:
        return bcrypt.checkpw(passwort.encode("utf-8"), hashed.encode("utf-8"))
    except ValueError:
        return False


def create_access_token(user_id: int) -> str:
    now = datetime.datetime.now(tz=datetime.timezone.utc)
    payload = {"sub": str(user_id), "iat": now, "exp": now + TOKEN_TTL}
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALG)


def get_current_user(
    cred: HTTPAuthorizationCredentials | None = Depends(_bearer),
    db: Session = Depends(get_db),
) -> models.User:
    err = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Nicht angemeldet",
        headers={"WWW-Authenticate": "Bearer"},
    )
    if cred is None or not cred.credentials:
        raise err
    user = user_from_token(cred.credentials, db)
    if user is None:
        raise err
    return user


def user_from_token(token: str, db: Session) -> models.User | None:
    """Benutzer aus einem rohen JWT auflösen (für Header ODER ?token=...)."""
    if not token:
        return None
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALG])
        user_id = int(payload["sub"])
    except (jwt.PyJWTError, KeyError, ValueError):
        return None
    user = db.get(models.User, user_id)
    if user is None or not user.is_active:
        return None
    return user


def require_admin(user: models.User = Depends(get_current_user)) -> models.User:
    if not user.is_admin:
        raise HTTPException(status_code=403, detail="Adminrechte erforderlich")
    return user
