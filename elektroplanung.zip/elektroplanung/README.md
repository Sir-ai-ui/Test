# Elektroplanung – Backend (FastAPI + PostgreSQL)

Grundgerüst für Phase 1 (Backend), 2 (Datenbank) und 6 (Datei-Upload).
Login/Auth (Phase 3) und Email (Phase 5) lassen sich später ohne Umbau ergänzen –
die `users`-Tabelle ist bereits angelegt.

## Aufbau

```
elektroplanung/
├── docker-compose.yml        # FastAPI + PostgreSQL
├── backend/
│   ├── Dockerfile
│   ├── requirements.txt
│   ├── main.py               # App-Start, bindet Router ein
│   ├── database.py           # DB-Verbindung
│   ├── models.py             # Tabellen: users, projekte, dateien
│   ├── schemas.py            # Validierung (Pydantic)
│   └── routers/
│       ├── projekte.py       # CRUD für Projekte
│       └── upload.py         # Datei-Upload/Download
└── frontend/
    └── demo.html             # Beispiel: API per fetch() anbinden
```

## Vor dem Start

In `docker-compose.yml` an **zwei Stellen** das Passwort
`bitte_hier_aendern` durch ein eigenes ersetzen (beide gleich!).

## Starten

```bash
docker compose up -d --build
```

Prüfen:

```bash
docker compose ps
docker compose logs -f backend
```

Test direkt auf dem Server:

```bash
docker compose exec backend curl -s http://localhost:8000/api/health
# -> {"status":"ok"}
```

## Über NPM erreichbar machen

Das Backend hängt im Netzwerk `vikunja_internal`. Im Nginx Proxy Manager
einen neuen Proxy Host anlegen (z. B. `api.elektroplanung.domain.de`):

- Forward Hostname: `elektroplanung-api`
- Forward Port: `8000`

API-Doku danach unter: `https://api.elektroplanung.domain.de/docs`

## Frontend anbinden

`demo.html` zeigt das Prinzip: per `fetch("/api/projekte")` Daten holen
und anzeigen. In deine bestehende `index.html` übernimmst du nur die
`fetch`-Aufrufe aus dem `<script>`-Block.

Damit `/api/...` aus dem Frontend funktioniert: im NPM beim Frontend-Host
einen "Custom Location" `/api` anlegen, der auf `elektroplanung-api:8000`
zeigt. Alternativ die volle API-Domain im JavaScript verwenden.

## Nächste Schritte

- Phase 3: `routers/auth.py` (Login, JWT, Passwort-Hashing mit `passlib`/`bcrypt`)
- Phase 5: Email (SMTP) für Bestätigungen/Benachrichtigungen
- Produktiv: DB-Migrationen mit `alembic` statt `create_all`
