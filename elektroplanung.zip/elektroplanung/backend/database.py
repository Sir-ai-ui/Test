"""
Datenbankverbindung (PostgreSQL via SQLAlchemy).

Die Zugangsdaten kommen aus Umgebungsvariablen, die in der
docker-compose.yml gesetzt werden. So liegen keine Passwoerter im Code.
"""
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

# Aus der docker-compose.yml gesetzt
DB_USER = os.getenv("POSTGRES_USER", "elektro")
DB_PASS = os.getenv("POSTGRES_PASSWORD", "changeme")
DB_NAME = os.getenv("POSTGRES_DB", "elektroplanung")
DB_HOST = os.getenv("POSTGRES_HOST", "db")   # = Service-Name des DB-Containers
DB_PORT = os.getenv("POSTGRES_PORT", "5432")

DATABASE_URL = f"postgresql+psycopg2://{DB_USER}:{DB_PASS}@{DB_HOST}:{DB_PORT}/{DB_NAME}"

# pool_pre_ping verhindert "stale connection"-Fehler nach Leerlauf
engine = create_engine(DATABASE_URL, pool_pre_ping=True)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()


def get_db():
    """FastAPI-Dependency: liefert eine DB-Session und schliesst sie sauber."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
