"""
Haupteinstiegspunkt der FastAPI-Anwendung.

Startet die App, erstellt beim Start automatisch die Tabellen und bindet
die Router ein. Die interaktive API-Doku ist nach dem Start unter
/docs erreichbar.
"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from database import Base, engine
import models  # noqa: F401 - sorgt dafuer, dass die Tabellen registriert werden
from routers import projekte, upload

# Tabellen anlegen, falls noch nicht vorhanden.
# (Fuer spaeter / Produktivbetrieb ist "Alembic" fuer Migrationen sinnvoll.)
Base.metadata.create_all(bind=engine)

app = FastAPI(title="Elektroplanung API", version="0.1.0")

# CORS: erlaubt dem Frontend (andere Domain) Zugriffe auf die API.
# Fuer den Start offen; spaeter auf deine Domain einschraenken.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],          # spaeter: ["https://elektroplanung.domain.de"]
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(projekte.router)
app.include_router(upload.router)


@app.get("/api/health")
def health():
    """Einfacher Test-Endpunkt: laeuft die API?"""
    return {"status": "ok"}
