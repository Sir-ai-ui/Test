"""
Datenbank-Tabellen.

Wichtig: Die users-Tabelle ist von Anfang an dabei, auch wenn der Login
erst spaeter kommt. Projekte haben bereits ein (vorerst optionales)
user_id-Feld, damit du sie spaeter einem Benutzer zuordnen kannst, ohne
die Datenbank umbauen zu muessen.
"""
from datetime import datetime
from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey
from sqlalchemy.orm import relationship

from database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    name = Column(String(255), nullable=True)
    # Wird erst gefuellt, wenn der Login (Phase 3) dazukommt:
    passwort_hash = Column(String(255), nullable=True)
    erstellt_am = Column(DateTime, default=datetime.utcnow)

    projekte = relationship("Projekt", back_populates="besitzer")


class Projekt(Base):
    __tablename__ = "projekte"

    id = Column(Integer, primary_key=True, index=True)
    projektname = Column(String(255), nullable=False)
    kunde = Column(String(255), nullable=True)
    adresse = Column(String(500), nullable=True)
    status = Column(String(50), default="geplant")  # geplant / in_bearbeitung / abgeschlossen
    notizen = Column(Text, nullable=True)

    # Vorerst optional (nullable) - wird mit dem Login zur Pflicht:
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)

    erstellt_am = Column(DateTime, default=datetime.utcnow)
    geaendert_am = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    besitzer = relationship("User", back_populates="projekte")
    dateien = relationship("Datei", back_populates="projekt", cascade="all, delete-orphan")


class Datei(Base):
    __tablename__ = "dateien"

    id = Column(Integer, primary_key=True, index=True)
    projekt_id = Column(Integer, ForeignKey("projekte.id"), nullable=False)
    dateiname = Column(String(255), nullable=False)   # Original-Name
    pfad = Column(String(500), nullable=False)        # Speicherort auf dem Server
    hochgeladen_am = Column(DateTime, default=datetime.utcnow)

    projekt = relationship("Projekt", back_populates="dateien")
