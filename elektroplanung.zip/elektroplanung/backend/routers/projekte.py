"""
CRUD-Endpunkte fuer Projekte.
CRUD = Create, Read, Update, Delete.
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

from database import get_db
import models
import schemas

router = APIRouter(prefix="/api/projekte", tags=["Projekte"])


@router.get("", response_model=List[schemas.ProjektRead])
def alle_projekte(db: Session = Depends(get_db)):
    """Alle Projekte auflisten."""
    return db.query(models.Projekt).order_by(models.Projekt.id.desc()).all()


@router.get("/{projekt_id}", response_model=schemas.ProjektRead)
def ein_projekt(projekt_id: int, db: Session = Depends(get_db)):
    """Ein einzelnes Projekt abrufen."""
    projekt = db.query(models.Projekt).get(projekt_id)
    if not projekt:
        raise HTTPException(status_code=404, detail="Projekt nicht gefunden")
    return projekt


@router.post("", response_model=schemas.ProjektRead, status_code=201)
def projekt_anlegen(daten: schemas.ProjektCreate, db: Session = Depends(get_db)):
    """Neues Projekt anlegen."""
    projekt = models.Projekt(**daten.model_dump())
    db.add(projekt)
    db.commit()
    db.refresh(projekt)
    return projekt


@router.put("/{projekt_id}", response_model=schemas.ProjektRead)
def projekt_aktualisieren(
    projekt_id: int, daten: schemas.ProjektUpdate, db: Session = Depends(get_db)
):
    """Projekt aktualisieren (nur uebergebene Felder werden geaendert)."""
    projekt = db.query(models.Projekt).get(projekt_id)
    if not projekt:
        raise HTTPException(status_code=404, detail="Projekt nicht gefunden")

    # exclude_unset: nur Felder uebernehmen, die wirklich mitgeschickt wurden
    for feld, wert in daten.model_dump(exclude_unset=True).items():
        setattr(projekt, feld, wert)

    db.commit()
    db.refresh(projekt)
    return projekt


@router.delete("/{projekt_id}", status_code=204)
def projekt_loeschen(projekt_id: int, db: Session = Depends(get_db)):
    """Projekt loeschen (inkl. zugehoeriger Dateien-Eintraege)."""
    projekt = db.query(models.Projekt).get(projekt_id)
    if not projekt:
        raise HTTPException(status_code=404, detail="Projekt nicht gefunden")
    db.delete(projekt)
    db.commit()
    return None
