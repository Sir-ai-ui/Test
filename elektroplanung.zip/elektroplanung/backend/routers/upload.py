"""
Datei-Upload zu einem Projekt (Phase 6).

Dateien werden im Ordner /app/uploads gespeichert (per Docker-Volume auf
dem Server persistent gemacht). In der Datenbank wird nur der Verweis
(Name + Pfad) abgelegt.
"""
import os
import uuid
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from database import get_db
import models

router = APIRouter(prefix="/api/projekte", tags=["Dateien"])

UPLOAD_DIR = os.getenv("UPLOAD_DIR", "/app/uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)


@router.post("/{projekt_id}/dateien")
async def datei_hochladen(
    projekt_id: int, datei: UploadFile = File(...), db: Session = Depends(get_db)
):
    """Datei zu einem Projekt hochladen."""
    projekt = db.query(models.Projekt).get(projekt_id)
    if not projekt:
        raise HTTPException(status_code=404, detail="Projekt nicht gefunden")

    # Eindeutigen Dateinamen erzeugen, damit nichts ueberschrieben wird
    endung = os.path.splitext(datei.filename)[1]
    speicher_name = f"{uuid.uuid4().hex}{endung}"
    voller_pfad = os.path.join(UPLOAD_DIR, speicher_name)

    with open(voller_pfad, "wb") as f:
        f.write(await datei.read())

    eintrag = models.Datei(
        projekt_id=projekt_id,
        dateiname=datei.filename,   # Original-Name fuer die Anzeige
        pfad=voller_pfad,
    )
    db.add(eintrag)
    db.commit()
    db.refresh(eintrag)

    return {"id": eintrag.id, "dateiname": eintrag.dateiname}


@router.get("/dateien/{datei_id}")
def datei_herunterladen(datei_id: int, db: Session = Depends(get_db)):
    """Eine gespeicherte Datei herunterladen."""
    eintrag = db.query(models.Datei).get(datei_id)
    if not eintrag or not os.path.exists(eintrag.pfad):
        raise HTTPException(status_code=404, detail="Datei nicht gefunden")
    return FileResponse(eintrag.pfad, filename=eintrag.dateiname)


@router.delete("/dateien/{datei_id}", status_code=204)
def datei_loeschen(datei_id: int, db: Session = Depends(get_db)):
    """Datei loeschen (von der Platte und aus der Datenbank)."""
    eintrag = db.query(models.Datei).get(datei_id)
    if not eintrag:
        raise HTTPException(status_code=404, detail="Datei nicht gefunden")
    if os.path.exists(eintrag.pfad):
        os.remove(eintrag.pfad)
    db.delete(eintrag)
    db.commit()
    return None
