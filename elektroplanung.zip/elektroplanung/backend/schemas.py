"""
Pydantic-Schemas: definieren, wie Daten rein- (Create) und rausgehen (Read).
FastAPI nutzt diese automatisch zur Validierung und fuer die API-Doku.
"""
from datetime import datetime
from typing import Optional, List
from pydantic import BaseModel


# ---------- Datei ----------
class DateiRead(BaseModel):
    id: int
    dateiname: str
    hochgeladen_am: datetime

    class Config:
        from_attributes = True   # erlaubt das Befuellen aus SQLAlchemy-Objekten


# ---------- Projekt ----------
class ProjektBase(BaseModel):
    projektname: str
    kunde: Optional[str] = None
    adresse: Optional[str] = None
    status: Optional[str] = "geplant"
    notizen: Optional[str] = None


class ProjektCreate(ProjektBase):
    """Felder beim Anlegen eines Projekts."""
    pass


class ProjektUpdate(BaseModel):
    """Beim Aktualisieren ist alles optional."""
    projektname: Optional[str] = None
    kunde: Optional[str] = None
    adresse: Optional[str] = None
    status: Optional[str] = None
    notizen: Optional[str] = None


class ProjektRead(ProjektBase):
    """Was die API zurueckgibt."""
    id: int
    erstellt_am: datetime
    geaendert_am: datetime
    dateien: List[DateiRead] = []

    class Config:
        from_attributes = True
